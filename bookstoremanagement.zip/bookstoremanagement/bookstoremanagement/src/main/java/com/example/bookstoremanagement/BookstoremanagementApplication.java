package com.example.bookstoremanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoremanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoremanagementApplication.class, args);
	}

}
