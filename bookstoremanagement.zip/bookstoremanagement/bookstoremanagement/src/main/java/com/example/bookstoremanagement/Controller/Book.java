package com.example.bookstoremanagement.Controller;


import com.example.bookstoremanagement.Models.BookApp;
import com.example.bookstoremanagement.Repository.BookRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class Book {
    @Autowired
    private BookRepository bookRepository;

    @Transactional
    @PostMapping("/bookentry")
    public ResponseEntity<Map<String, String>> bookEntry(@RequestBody BookApp bookApp){
        BookApp bookobj = bookRepository.save(bookApp);
        Map<String, String> response = new HashMap<>();
        response.put("status", "Book Entry done");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/retrievebooksdetails")
    public ResponseEntity<List<BookApp>> bookList(){
        List<BookApp> books = bookRepository.findAll();
        return ResponseEntity.ok(books);
    }
}
