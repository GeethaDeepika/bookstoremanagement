package com.example.bookstoremanagement.Repository;

import com.example.bookstoremanagement.Models.BookApp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<BookApp, Long> {
}
